<?php

/**
 * @package xpay
 */
class XPayItem extends xPDOSimpleObject
{
}