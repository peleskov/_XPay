<?php
class XPayOrder extends xPDOSimpleObject {}