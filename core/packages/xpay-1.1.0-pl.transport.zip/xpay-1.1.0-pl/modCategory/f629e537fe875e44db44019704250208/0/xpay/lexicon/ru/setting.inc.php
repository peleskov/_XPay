<?php

$_lang['area_xpay_main'] = 'XPay';

$_lang['setting_xpay_api_url'] = 'API url для запросов';
$_lang['setting_xpay_api_url_desc'] = 'На этот адрес будут отправляться запросы к АПИ';
$_lang['setting_xpay_api_key'] = 'API токен';
$_lang['setting_xpay_api_key_desc'] = 'API токен выдается эквайрингом';
$_lang['setting_xpay_merchant_id'] = 'ID мерчанта в эквайринге';
$_lang['setting_xpay_ttl'] = 'Время жизни инвойса';
$_lang['setting_xpay_currency'] = 'Валюта мерчанта';
$_lang['setting_xpay_successID'] = 'ID ресурса успешная оплата';
$_lang['setting_xpay_failureID'] = 'ID ресурса ошибка оплаты';
