<?php
require_once (dirname(__DIR__) . '/xpayorder.class.php');
class XPayOrder_mysql extends XPayOrder {}