<?php

$_lang['area_xpay_main'] = 'XPay';

$_lang['setting_xpay_api_url'] = 'API requests url';
$_lang['setting_xpay_api_url_desc'] = 'API requests will be sent to this url';
$_lang['setting_xpay_api_key'] = 'API key';
$_lang['setting_xpay_api_key_desc'] = 'API token is issued by acquiring';
$_lang['setting_xpay_merchant_id'] = 'Merchant ID in acquiring';
$_lang['setting_xpay_ttl'] = 'Invoice lifetime';
$_lang['setting_xpay_currency'] = 'Merchant currency';
$_lang['setting_xpay_successID'] = 'Resource ID successful payment';
$_lang['setting_xpay_failureID'] = 'Resource ID payment error';
