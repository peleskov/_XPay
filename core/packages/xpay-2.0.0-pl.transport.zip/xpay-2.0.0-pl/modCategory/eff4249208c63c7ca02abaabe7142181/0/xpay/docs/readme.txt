--------------------
XPay
--------------------
Author: Sergei Peleskov <info!s1temaker.ru>
--------------------

XPay for MODx Revolution.